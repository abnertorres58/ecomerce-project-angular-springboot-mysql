package com.freudromero.ecomerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEcomerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
